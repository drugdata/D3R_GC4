Dataset packet provided: CatS_initial_packet_to_participants.zip

CatS_target_D3R_GC4.fasta: Protein sequence file of the Cathepsin S construct used.

CatS_score_compounds_D3R_GC4.csv: CSV file of 459 compounds and their corresponding SMILES string.

CatS_FESet_compounds_D3R_GC4.csv: CSV file of 39 compounds selected from CatS_score_compounds_D3R_GC4.csv for explicit-solvent relative or absolute free energy calculations.
