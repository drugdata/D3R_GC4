Dataset packet provided: BACE_initial_packet_to_participants.zip

BACE_target_D3R_GC4.fasta: Protein sequence file of the BACE construct used.

BACE_pose_compounds_D3R_GC4.csv: CSV file of 20 compounds and their corresponding SMILES.

BACE_score_compounds_D3R_GC4.csv: CSV file of 154 compounds and their corresponding SMILES string.

BACE_FESet_compounds_D3R_GC4.csv: CSV file of 34 compounds for explicit-solvent relative or absolute free energy calculations.
